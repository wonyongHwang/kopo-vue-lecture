<!-- src/views/RegisterView.vue -->
<template>
    <div class="d-flex justify-content-center align-items-center bg-light">
      <div class="card shadow-sm p-4" style="width: 360px;">
        <h3 class="text-center mb-3">회원가입</h3>
  
        <div class="mb-3">
          <label class="form-label">이메일</label>
          <input
            v-model="email"
            type="email"
            class="form-control"
            placeholder="you@example.com"
          />
        </div>
  
        <div class="mb-3">
          <label class="form-label">비밀번호</label>
          <input
            v-model="password"
            type="password"
            class="form-control"
            placeholder="••••••••"
          />
        </div>
  
        <div class="mb-3">
          <label class="form-label">비밀번호 확인</label>
          <input
            v-model="passwordConfirm"
            type="password"
            class="form-control"
            placeholder="••••••••"
          />
        </div>
  
        <button class="btn btn-success w-100" @click="handleRegister">
          회원가입
        </button>
  
        <p v-if="message" class="text-success mt-2 text-center">
          {{ message }}
        </p>
        <p v-if="errorMessage" class="text-danger mt-2 text-center">
          {{ errorMessage }}
        </p>
  
        <div class="text-center mt-3">
          <router-link to="/" class="text-primary fw-bold">
            로그인 화면으로 돌아가기
          </router-link>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue'
  import { createUserWithEmailAndPassword } from 'firebase/auth'
  import { auth } from '../firebase'
  import { useRouter } from 'vue-router'
  
  const email = ref('')
  const password = ref('')
  const passwordConfirm = ref('')
  const errorMessage = ref('')
  const message = ref('')
  
  const router = useRouter()
  
  const handleRegister = async () => {
    errorMessage.value = ''
    message.value = ''
  
    if (password.value !== passwordConfirm.value) {
      errorMessage.value = '비밀번호가 일치하지 않습니다.'
      return
    }
  
    try {
      await createUserWithEmailAndPassword(auth, email.value, password.value)
      message.value = '회원가입이 완료되었습니다!'
      setTimeout(() => router.push('/'), 1200)
    } catch (err) {
      errorMessage.value = '회원가입 실패: ' + err.code
    }
  }
  </script>
  