<!-- src/views/LoginView.vue -->
<template>
    <div class="d-flex justify-content-center align-items-center bg-light">
      <div class="card shadow-sm p-4" style="width: 360px;">
        <h3 class="text-center mb-3">로그인</h3>
  
        <div class="mb-3">
          <label class="form-label">이메일</label>
          <input
            v-model="email"
            type="email"
            class="form-control"
            placeholder="you@example.com"
          />
        </div>
  
        <div class="mb-3">
          <label class="form-label">비밀번호</label>
          <input
            v-model="password"
            type="password"
            class="form-control"
            placeholder="••••••••"
          />
        </div>
  
        <button class="btn btn-primary w-100" @click="handleLogin">
          로그인
        </button>
  
        <p v-if="errorMessage" class="text-danger mt-2 text-center">
          {{ errorMessage }}
        </p>
  
        <div class="text-center mt-3">
          <span>아직 회원이 아니신가요?</span>
          <router-link to="/register" class="text-primary fw-bold ms-1">
            가입하기
          </router-link>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue'
  import { signInWithEmailAndPassword } from 'firebase/auth'
  import { auth } from '../firebase'
  import { useRouter } from 'vue-router'
  
  const email = ref('')
  const password = ref('')
  const errorMessage = ref('')
  const router = useRouter()
  
  const handleLogin = async () => {
    errorMessage.value = ''
    try {
      await signInWithEmailAndPassword(auth, email.value, password.value)
      router.push('/main')
    } catch (err) {
      errorMessage.value = '로그인 실패: ' + err.code
    }
  }
  </script>
  