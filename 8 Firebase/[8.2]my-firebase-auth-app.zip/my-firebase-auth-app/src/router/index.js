// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '../views/LoginView.vue'
import RegisterView from '../views/RegisterView.vue'
import MainView from '../views/MainView.vue'
// src/router/index.js
const routes = [
    { path: '/', name: 'login', component: LoginView },
    { path: '/register', name: 'register', component: RegisterView },
    { path: '/main', name: 'main', component: MainView }, 
  ]
  
  const router = createRouter({
    history: createWebHistory(),
    routes,
  })
  
  export default router
  