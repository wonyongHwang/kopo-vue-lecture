<!-- src/views/MainView.vue -->
<template>
    <div v-if="checked">
      <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h4 class="mb-0">메인 화면</h4>
          <button class="btn btn-outline-danger btn-sm" @click="logout">
            로그아웃
          </button>
        </div>
  
        <div class="alert alert-primary" v-if="userEmail">
          로그인한 사용자: <strong>{{ userEmail }}</strong>
        </div>
  
        <TodoList />
        
      </div>
    </div>
  
    <!-- 아직 로그인 상태 체크 중일 때 -->
    <div v-else class="d-flex vh-100 justify-content-center align-items-center">
      <div class="spinner-border" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref, onMounted, onUnmounted } from 'vue'
  import { onAuthStateChanged, signOut } from 'firebase/auth'
  import { auth } from '../firebase'
  import { useRouter } from 'vue-router'
  import TodoList from '../components/TodoList.vue'

  
  const router = useRouter()
  const userEmail = ref(null)
  const checked = ref(false)   // 로그인 상태 확인이 끝났는지 여부
  let unsubscribe = null
  
  onMounted(() => {
    // 새로고침 후에도 여기서 Firebase가 세션 복원 완료한 다음 콜백을 호출해 줌
    unsubscribe = onAuthStateChanged(auth, user => {
      if (!user) {
        // 로그인 안 되어 있으면 로그인 페이지로 돌려보냄
        router.replace('/')
      } else {
        userEmail.value = user.email
        checked.value = true   // 화면 렌더 시작
      }
    })
  })
  
  onUnmounted(() => {
    if (unsubscribe) unsubscribe()
  })
  
  const logout = async () => {
    await signOut(auth)
    router.push('/')
  }
  </script>
  