<!-- src/components/TodoList.vue -->
<template>
    <div class="card shadow-sm p-3">
      <h5 class="mb-3">Todo 목록 (Firestore)</h5>
  
      <!-- Firestore 연결/로딩 상태 -->
      <div v-if="isLoading" class="text-muted mb-2">
        Firestore에서 데이터를 불러오는 중입니다...
      </div>
      <div v-if="loadError" class="text-danger mb-2">
        {{ loadError }}
      </div>
  
      <!-- 추가 폼 -->
      <form class="d-flex mb-2" @submit.prevent="addTodo">
        <input
          v-model="newTodo"
          class="form-control me-2"
          placeholder="할 일을 입력하세요"
        />
        <button class="btn btn-primary" :disabled="isAdding">
          {{ isAdding ? '추가 중...' : '추가' }}
        </button>
      </form>
  
      <!-- insert 작업 결과 메시지 -->
      <p v-if="addMessage" class="text-success small mb-1">
        {{ addMessage }}
      </p>
      <p v-if="addError" class="text-danger small mb-1">
        {{ addError }}
      </p>
  
      <!-- 실제 Firestore에서 온 데이터만 목록에 표시 -->
      <ul class="list-group mt-2" v-if="!isLoading && !loadError">
        <li
          v-for="todo in todos"
          :key="todo.id"
          class="list-group-item d-flex justify-content-between align-items-center"
        >
          {{ todo.text }}
          <span class="badge bg-secondary">
            {{ todo.createdAt?.toDate?.().toLocaleString?.() ?? '' }}
          </span>
        </li>
  
        <li v-if="todos.length === 0" class="list-group-item text-muted">
          아직 등록된 할 일이 없습니다.
        </li>
      </ul>
    </div>
  </template>
  
  
  
<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { auth, db } from '../firebase'
import {
  collection,
  addDoc,
  serverTimestamp,
  onSnapshot,
  query,
  where
} from 'firebase/firestore'
import { onAuthStateChanged } from 'firebase/auth'

const newTodo = ref('')
const todos = ref([])

// 상태 관리
const isLoading = ref(true)
const loadError = ref('')
const isAdding = ref(false)
const addError = ref('')
const addMessage = ref('')

let unsubscribeTodos = null
let unsubscribeAuth = null

const subscribeMyTodos = (uid) => {
  console.log('[Firestore] todos(내 것만, 정렬 없음) 구독 시작, uid =', uid)

  const todosRef = collection(db, 'todos')
  const q = query(
    todosRef,
    where('uid', '==', uid)
  )

  unsubscribeTodos = onSnapshot(
    q,
    (snapshot) => {
      isLoading.value = false
      loadError.value = ''

      // 🔽 정렬은 클라이언트에서(선택)
      todos.value = snapshot.docs
        .map(doc => ({
          id: doc.id,
          ...doc.data()
        }))
        .sort((a, b) => {
          const ta = a.createdAt?.seconds ?? 0
          const tb = b.createdAt?.seconds ?? 0
          return tb - ta // 최신순
        })
    },
    (err) => {
      isLoading.value = false
      loadError.value = '데이터를 불러오는 중 오류가 발생했습니다.'
      console.error('[Firestore] onSnapshot 에러:', err)
    }
  )
}

onMounted(() => {
  unsubscribeAuth = onAuthStateChanged(auth, (user) => {
    if (unsubscribeTodos) {
      unsubscribeTodos()
      unsubscribeTodos = null
    }

    todos.value = []
    isLoading.value = true
    loadError.value = ''

    if (!user) {
      isLoading.value = false
      loadError.value = '로그인 후 할 일을 확인할 수 있습니다.'
      return
    }

    subscribeMyTodos(user.uid)
  })
})

onUnmounted(() => {
  if (unsubscribeTodos) unsubscribeTodos()
  if (unsubscribeAuth) unsubscribeAuth()
})

const addTodo = async () => {
  addError.value = ''
  addMessage.value = ''

  if (!auth.currentUser) {
    alert('로그인 후 사용해주세요.')
    return
  }

  if (!newTodo.value.trim()) {
    addError.value = '내용을 입력해주세요.'
    return
  }

  isAdding.value = true

  try {
    const todosRef = collection(db, 'todos')
    const docRef = await addDoc(todosRef, {
      text: newTodo.value.trim(),
      uid: auth.currentUser.uid,
      createdAt: serverTimestamp()
    })

    console.log('[Firestore] addDoc 성공 - 문서 ID:', docRef.id)
    addMessage.value = '할 일이 Firestore에 정상적으로 저장되었습니다.'
    newTodo.value = ''
  } catch (err) {
    console.error('[Firestore] addDoc 에러:', err)
    addError.value = `할 일 저장 중 오류가 발생했습니다: ${err.code || err.message}`
  } finally {
    isAdding.value = false
  }
}
</script>

