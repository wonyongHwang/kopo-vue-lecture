// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '../views/LoginView.vue'
import RegisterView from '../views/RegisterView.vue'
import MainView from '../views/MainView.vue'
// src/router/index.js
const routes = [
    { path: '/', name: 'login', component: LoginView },
    { path: '/register', name: 'register', component: RegisterView },
    { path: '/main', name: 'main', component: MainView }, // meta 제거
  ]
  
  const router = createRouter({
    history: createWebHistory(),
    routes,
  })
  
  // beforeEach 가드 통째로 삭제해도 됨
  export default router
  