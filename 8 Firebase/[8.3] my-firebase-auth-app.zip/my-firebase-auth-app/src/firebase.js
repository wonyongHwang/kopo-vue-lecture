// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from 'firebase/auth'
import { getFirestore } from 'firebase/firestore'

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "<당신의 Firebase API Key를 넣어주세요>",
  authDomain: "<당신의 Firebase Auth Domain을 넣어주세요>",
  projectId: "<당신의 Firebase Project ID를 넣어주세요>",
  storageBucket: "<당신의 Firebase Storage Bucket을 넣어주세요>",
  messagingSenderId: "<당신의 Firebase Messaging Sender ID를 넣어주세요>",
  appId: "<당신의 Firebase App ID를 넣어주세요>",
  measurementId: "<당신의 Firebase Measurement ID를 넣어주세요>"
};


// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

const auth = getAuth(app)
const db = getFirestore(app)

export { auth, db }