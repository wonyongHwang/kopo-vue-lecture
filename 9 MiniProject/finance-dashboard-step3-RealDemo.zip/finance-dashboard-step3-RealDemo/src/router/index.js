// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'
import { auth } from '../firebase'               // 🔥 핵심: Firebase Auth 직접 참조
import LoginView from '../views/LoginView.vue'
import RegisterView from '../views/RegisterView.vue'
import DashboardView from '../views/DashboardView.vue'

const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', name: 'login', component: LoginView, meta: { guestOnly: true } },
  { path: '/register', name: 'register', component: RegisterView, meta: { guestOnly: true } },
  { path: '/dashboard', name: 'dashboard', component: DashboardView, meta: { requiresAuth: true } }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  const isLoggedIn = !!auth.currentUser      // 🔥 핵심: 언제나 정확함
  console.log('auth.currentUser ', auth.currentUser)
  // 1) 로그인 필요한데 로그인 안됨
  if (to.meta.requiresAuth && !isLoggedIn) {
    return next('/login')
  }

  // 2) 로그인된 상태에서 /login 또는 /register 접근
  if (to.meta.guestOnly && isLoggedIn) {
    return next('/dashboard')
  }

  next()
})

export default router
