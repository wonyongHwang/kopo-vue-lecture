import axios from 'axios'

const BASE_URL = 'https://api.coingecko.com/api/v3'

export async function fetchSimpleCryptoPrices() {
  const response = await axios.get(
    `${BASE_URL}/simple/price`,
    {
      params: {
        ids: 'bitcoin,ethereum',
        vs_currencies: 'usd,krw'
      }
    }
  )
  return response.data  // { bitcoin: { usd: ..., krw: ... }, ... }
}

// 🔹 새로 추가: BTC/ETH 가격 히스토리
// id: 'bitcoin' 또는 'ethereum'
// days: 7, 30, 90 등
export async function fetchCryptoHistory(id, days = 30) {
  const response = await axios.get(
    `${BASE_URL}/coins/${id}/market_chart`,
    {
      params: {
        vs_currency: 'usd',
        days
      }
    }
  )
  // response.data.prices === [[timestamp(ms), price], ...]
  return response.data.prices
}