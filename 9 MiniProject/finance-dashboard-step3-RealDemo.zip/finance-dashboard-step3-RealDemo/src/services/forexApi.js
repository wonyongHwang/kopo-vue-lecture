// src/services/forexApi.js
import axios from 'axios'

// 🔧 수정된 부분
const BASE_URL = 'https://api.frankfurter.dev/v1'

// USD 기준으로 KRW, EUR, JPY 환율 조회
export async function fetchUsdToKrwAndOthers() {
  const response = await axios.get(`${BASE_URL}/latest`, {
    params: {
      from: 'USD',
      to: 'KRW,EUR,JPY'
    }
  })
  // 응답 예: { amount, base, date, rates: { KRW: 1300..., EUR: ..., JPY: ... } }
  return response.data
}
