// src/stores/chartPrefStore.js
import { defineStore } from 'pinia'
import { db } from '../firebase'
import {
  doc,
  getDoc,
  setDoc
} from 'firebase/firestore'
import { useUserStore } from './userStore'

export const useChartPrefStore = defineStore('chartPrefs', {
  state: () => ({
    btcDays: 30,
    ethDays: 30,
    loading: false,
    error: ''
  }),
  actions: {
    async loadPrefs() {
      this.loading = true
      this.error = ''
      try {
        const userStore = useUserStore()
        if (!userStore.user) return

        const ref = doc(db, 'chartPrefs', userStore.user.uid)
        const snap = await getDoc(ref)
        if (snap.exists()) {
          const data = snap.data()
          if (typeof data.btcDays === 'number') this.btcDays = data.btcDays
          if (typeof data.ethDays === 'number') this.ethDays = data.ethDays
        }
      } catch (err) {
        console.error('[chartPrefStore.loadPrefs]', err.code, err.message)
        this.error = '차트 설정을 불러오는데 실패했습니다.'
      } finally {
        this.loading = false
      }
    },

    async setDays(asset, days) {
      this.error = ''
      try {
        const userStore = useUserStore()
        if (!userStore.user) {
          this.error = '로그인이 필요합니다.'
          throw new Error('NOT_LOGGED_IN')
        }

        if (asset === 'btc') this.btcDays = days
        if (asset === 'eth') this.ethDays = days

        const ref = doc(db, 'chartPrefs', userStore.user.uid)
        await setDoc(ref, {
          btcDays: this.btcDays,
          ethDays: this.ethDays
        }, { merge: true })
      } catch (err) {
        console.error('[chartPrefStore.setDays]', err.code, err.message)
        if (!this.error) {
          this.error = '차트 설정 저장에 실패했습니다.'
        }
      }
    }
  }
})
