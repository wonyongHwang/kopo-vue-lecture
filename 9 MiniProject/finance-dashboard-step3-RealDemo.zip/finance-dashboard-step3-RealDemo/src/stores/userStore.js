// src/stores/userStore.js
import { defineStore } from 'pinia'
import { auth } from '../firebase'
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged
} from 'firebase/auth'
import router from '../router'              // 🔥 이 줄 추가


export const useUserStore = defineStore('user', {
  state: () => ({
    user: null,
    loading: false,
    error: ''
  }),
  actions: {
    async register(email, password) {
      this.loading = true
      this.error = ''
      try {
        const cred = await createUserWithEmailAndPassword(auth, email, password)
        this.user = cred.user
      } catch (err) {
        this.error = err.message
        throw err
      } finally {
        this.loading = false
      }
    },
    async login(email, password) {
      this.loading = true
      this.error = ''
      try {
        const cred = await signInWithEmailAndPassword(auth, email, password)
        this.user = cred.user
      } catch (err) {
        this.error = err.message
        throw err
      } finally {
        this.loading = false
      }
    },
    async logout() {
      await signOut(auth)
      this.user = null
    },
    initAuthListener() {
        onAuthStateChanged(auth, user => {
          this.user = user
    
          const current = router.currentRoute.value
    
          // 🔹 로그인된 상태인데 /login 또는 /register에 있다면 → /dashboard로 보낸다
          if (user && current.meta?.guestOnly) {
            router.replace({ name: 'dashboard' })
            return
          }
    
          // 🔹 로그아웃 상태인데 보호된 페이지에 있다면 → /login으로 보낸다
          if (!user && current.meta?.requiresAuth) {
            router.replace({ name: 'login' })
            return
          }
        })
    }
  }
})
