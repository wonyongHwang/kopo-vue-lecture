import { createApp } from 'vue'
import { createPinia } from 'pinia' // step 3
import App from './App.vue'
import router from './router'

import 'vuetify/styles' 
import { createVuetify } from 'vuetify' 
import * as components from 'vuetify/components' 
import * as directives from 'vuetify/directives'

import { useUserStore } from './stores/userStore' // step 3
import { emitter } from './plugins/eventBus' // step 3

// components, directives: Vuetify 컴포넌트를 전역 등록
// theme: 라이트/다크 테마 정의
const vuetify = createVuetify({
    components,
    directives,
    theme: {
      defaultTheme: 'light',
      themes: {
        light: { dark: false },
        dark: { dark: true }
      }
    }
  })
const app = createApp(App)
const pinia = createPinia() // step 3

app.use(pinia) // step 3
app.use(router)
app.use(vuetify) 

// Pinia 스토어 초기화 (Auth 상태 감시) // step 3
const userStore = useUserStore()
userStore.initAuthListener()

// mitt 전역 등록 // step 3
app.config.globalProperties.$bus = emitter

app.mount('#app')
