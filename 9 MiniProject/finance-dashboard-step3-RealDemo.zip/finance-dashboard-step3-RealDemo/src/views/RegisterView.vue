<!-- src/views/RegisterView.vue -->
<template>
  <div class="auth-page">
    <div class="auth-card">
      <h1 class="auth-title">회원가입</h1>

      <form @submit.prevent="handleRegister">
        <div class="form-row">
          <label for="email">이메일</label>
          <input
            id="email"
            v-model="email"
            type="email"
            placeholder="example@email.com"
            required
          />
        </div>

        <div class="form-row">
          <label for="password">비밀번호</label>
          <input
            id="password"
            v-model="password"
            type="password"
            placeholder="8자 이상 입력"
            required
          />
        </div>

        <div class="form-row">
          <label for="password">비밀번호 확인</label>
          <input
            id="password"
            v-model="passwordConfirm"
            type="password"
            placeholder="8자 이상 입력"
            required
          />
        </div>

        <button
          type="submit"
          class="submit-btn"
        >
           회원가입
        </button>
      </form>

      <p class="auth-footer-text">
        이미 계정이 있으신가요?
        <RouterLink to="/login" class="auth-footer-link">
          로그인 하러 가기
        </RouterLink>
      </p>
    </div>
  </div>
</template>

<script setup>


import { ref, getCurrentInstance } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/userStore'

const router = useRouter()
const email = ref('')
const password = ref('')
const passwordConfirm = ref('')


// Pinia userStore 사용 (Firebase Auth 연동)
const userStore = useUserStore()

// (선택) mitt 토스트 사용 준비 – 설정 안 했으면 없어도 됨
const { appContext } = getCurrentInstance()
const bus = appContext.config.globalProperties.$bus

const handleRegister = async () => {
  if (password.value.length < 8) {
    const msg = '비밀번호는 8자 이상으로 입력해 주세요.'
    if (bus?.emit) {
      bus.emit('toast', { type: 'error', message: msg })
    } else {
      alert(msg)
    }
    return
  }


  // 비밀번호 / 비밀번호 확인 일치 여부 검사
  if (password.value !== passwordConfirm.value) {
    const msg = '비밀번호와 비밀번호 확인이 일치하지 않습니다.'
    if (bus?.emit) {
      bus.emit('toast', { type: 'error', message: msg })
    } else {
      alert(msg)
    }
    return
  }

  try {
    await userStore.register(email.value, password.value)

    const successMsg = '회원가입이 완료되었습니다. 로그인 해 주세요.'
    if (bus?.emit) {
      bus.emit('toast', { type: 'success', message: successMsg })
    } else {
      alert(successMsg)
    }

    router.push('/login')
  } catch (err) {
    // userStore.error 에 메시지가 설정되어 있음
    const failMsg = userStore.error || '회원가입에 실패했습니다.'
    if (bus?.emit) {
      bus.emit('toast', { type: 'error', message: failMsg })
    } else {
      alert(failMsg)
    }
    console.error(err)
  }
}
</script>

<style scoped>
/* 🔹 로그인 화면과 같은 톤/레이아웃 */
.auth-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f3f4f6; /* 연한 회색 배경 */
}

.auth-card {
  width: 100%;
  max-width: 420px;
  padding: 40px 32px;
  border-radius: 16px;
  background: #ffffff;
  box-shadow: 0 10px 30px rgba(15, 23, 42, 0.12);
}

.auth-title {
  margin-bottom: 24px;
  font-size: 28px;
  font-weight: 700;
}

/* 폼 레이아웃 */
form {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

/* 한 줄씩 정렬 */
.form-row {
  display: flex;
  flex-direction: column;
}

label {
  font-size: 14px;
  margin-bottom: 6px;
  color: #4b5563;
}

/* 인풋 스타일 – 로그인 화면과 동일한 느낌 */
input {
  padding: 10px 12px;
  border-radius: 8px;
  border: 1px solid #d1d5db;
  font-size: 15px;
  outline: none;
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}

input:focus {
  border-color: #6366f1;
  box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
}

/* 제출 버튼 – 로그인 버튼과 동일 스타일 */
.submit-btn {
  width: 100%;
  margin-top: 8px;
  padding: 12px 0;
  font-size: 16px;
  font-weight: 600;
  border-radius: 999px;
  border: none;
  cursor: pointer;
  background: #6366f1;
  color: white;
  transition: background 0.15s ease, transform 0.05s ease;
}

.submit-btn:hover {
  background: #4f46e5;
}

.submit-btn:active {
  transform: translateY(1px);
}

/* 에러 텍스트 */
.error-text {
  margin-top: 4px;
  font-size: 13px;
  color: #ef4444;
}

/* 하단 링크 문구 */
.auth-footer-text {
  margin-top: 16px;
  font-size: 14px;
  text-align: center;
  color: #6b7280;
}

.auth-footer-link {
  margin-left: 4px;
  color: #4f46e5;
  text-decoration: underline;
  font-weight: 500;
}
</style>
