<template>
  <div class="dashboard-page">
    <header class="dashboard-header">
      <h1 class="dashboard-title">Finance Dashboard</h1>
      <p class="dashboard-subtitle">
        환율과 암호화폐 시세를 한눈에 확인하는 대시보드
      </p>
    </header>

    <div class="dashboard-grid">
      <div class="dashboard-card-wrapper">
        <ForexCard />
      </div>
      <div class="dashboard-card-wrapper">
        <CryptoCard />
      </div>
    </div>
    
  </div>
  <div class="dashboard-page">
    <MyChartBoard />
  </div>
</template>

<script setup>
import ForexCard from '../components/ForexCard.vue'
import CryptoCard from '../components/CryptoCard.vue'
import MyChartBoard from '../components/MyChartBoard.vue'
</script>

<style scoped>
/* 🔵 파란 계열 배경 + 전체 패딩 */
.dashboard-page {
  /* min-height: 100vh; */
  background: #e0f2fe; /* 연한 스카이블루 */
  padding: 32px 24px 40px;
}

/* 헤더 영역 */
.dashboard-header {
  max-width: 1400px;
  margin: 0 auto 28px;
}

.dashboard-title {
  font-size: 32px;
  font-weight: 800;
  margin-bottom: 6px;
}

.dashboard-subtitle {
  font-size: 14px;
  color: #64748b;
}

/* 📐 카드 2개를 화면 좌우로 거의 꽉 채우는 Grid 레이아웃 */
.dashboard-grid {
  max-width: 1400px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr)); /* 데스크톱에서 2열 */
  gap: 32px; /* 카드 사이 간격 */
}

/* 카드 래퍼: 높이 맞추기 위해 flex */
.dashboard-card-wrapper {
  display: flex;
}

/* 자식 컴포넌트 안의 .finance-card 공통 스타일 */
.dashboard-card-wrapper :deep(.finance-card) {
  flex: 1;                         /* 두 카드 높이 동일 */
  border-radius: 18px;
  background: #ffffff;
  box-shadow: 0 14px 35px rgba(15, 23, 42, 0.16);
  border: 1px solid rgba(148, 163, 184, 0.35);
}

/* 카드 내부 제목/부제 색감 통일 */
.dashboard-card-wrapper :deep(.v-card-title) {
  font-weight: 700;
  font-size: 18px;
  color: #0f172a;
}

.dashboard-card-wrapper :deep(.v-card-subtitle) {
  color: #94a3b8;
}

/* 📱 모바일에서는 1열로 */
@media (max-width: 900px) {
  .dashboard-grid {
    grid-template-columns: 1fr;
  }
}
</style>
