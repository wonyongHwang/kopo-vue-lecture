<!-- src/components/GlobalToast.vue -->
<template>
    <div class="toast-wrapper">
      <div
        v-for="(t, index) in toasts"
        :key="index"
        class="toast"
        :class="t.type"
      >
        {{ t.message }}
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref, onMounted, onUnmounted, getCurrentInstance } from 'vue'
  
  const toasts = ref([])
  
  const { appContext } = getCurrentInstance()
  const bus = appContext.config.globalProperties.$bus
  
  const handler = payload => {
    toasts.value.push(payload)
    setTimeout(() => {
      toasts.value.shift()
    }, 2000)
  }
  
  onMounted(() => {
    bus.on('toast', handler)
  })
  
  onUnmounted(() => {
    bus.off('toast', handler)
  })
  </script>
  
  <style scoped>
  .toast-wrapper {
    position: fixed;
    right: 1rem;
    bottom: 1rem;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    z-index: 9999;
  }
  .toast {
    padding: 0.5rem 1rem;
    border-radius: 4px;
    color: #fff;
  }
  .toast.success {
    background: #4caf50;
  }
  .toast.error {
    background: #f44336;
  }
  </style>
  