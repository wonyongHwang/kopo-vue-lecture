<!-- src/components/CryptoLineChart.vue -->
<template>
  <v-card class="chart-card">
    <v-card-title>{{ title }}</v-card-title>
    <v-card-subtitle>
      {{ days }}일 간 USD 기준 가격 추이
    </v-card-subtitle>

    <v-card-text>
      <div class="range-buttons">
        <v-btn
          v-for="d in [7, 30, 90]"
          :key="d"
          size="small"
          :variant="days === d ? 'flat' : 'text'"
          @click="changeRange(d)"
        >
          {{ d }}일
        </v-btn>
      </div>

      <div v-if="loading" class="loading">
        데이터를 불러오는 중...
      </div>

      <div v-else-if="error" class="error">
        {{ error }}
      </div>

      <div v-else class="chart-wrapper">
        <Line :data="chartData" :options="chartOptions" />
      </div>
    </v-card-text>
  </v-card>
</template>

<script setup>
import { ref, watch, onMounted, computed, getCurrentInstance } from 'vue'
import { Line } from 'vue-chartjs'
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  TimeScale,
  PointElement,
  Tooltip,
  Legend
} from 'chart.js'
import 'chartjs-adapter-date-fns'
import { fetchCryptoHistory } from '../services/cryptoApi'
import { useChartPrefStore } from '../stores/chartPrefStore'

ChartJS.register(
  LineElement,
  CategoryScale,
  LinearScale,
  TimeScale,
  PointElement,
  Tooltip,
  Legend
)

const props = defineProps({
  asset: { type: String, required: true }, // 'btc' or 'eth'
  title: { type: String, required: true }
})

const chartPrefStore = useChartPrefStore()

const loading = ref(false)
const error = ref('')
const prices = ref([]) // [[timestamp, price], ...]

const days = computed({
  get() {
    return props.asset === 'btc'
      ? chartPrefStore.btcDays
      : chartPrefStore.ethDays
  },
  set(value) {
    chartPrefStore.setDays(props.asset, value)
  }
})

// mitt 토스트(선택)
const { appContext } = getCurrentInstance()
const bus = appContext.config.globalProperties.$bus
const toast = (payload) => {
  if (bus && bus.emit) bus.emit('toast', payload)
}

const loadData = async () => {
  loading.value = true
  error.value = ''
  try {
    const id = props.asset === 'btc' ? 'bitcoin' : 'ethereum'
    const data = await fetchCryptoHistory(id, days.value)
    prices.value = data
  } catch (err) {
    console.error('[CryptoLineChart.loadData]', err)
    error.value = '차트 데이터를 불러오는데 실패했습니다.'
  } finally {
    loading.value = false
  }
}

const changeRange = async (d) => {
  await chartPrefStore.setDays(props.asset, d)
  await loadData()
  toast?.({
    type: 'success',
    message: `${props.title} 차트 범위를 ${d}일로 변경했습니다.`
  })
}

const chartData = computed(() => {
  const labels = prices.value.map(p => new Date(p[0]))
  const data = prices.value.map(p => p[1])

  return {
    labels,
    datasets: [
      {
        label: props.title,
        data,
        borderWidth: 2,
        pointRadius: 0,
        tension: 0.2
      }
    ]
  }
})

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    x: {
      type: 'time',
      time: { unit: 'day' }
    },
    y: {
      ticks: {
        callback: (value) => `$${value}`
      }
    }
  },
  plugins: {
    legend: { display: false }
  }
}

onMounted(async () => {
  // chartPrefStore는 Dashboard 진입 시 loadPrefs가 먼저 호출되었다고 가정
  await loadData()
})


</script>

<style scoped>

/* 🔥 하단 차트 카드를 상단 카드와 동일하게 라운드 처리하는 핵심 */
.chart-card {
  border-radius: 16px;           /* 상단 카드와 동일한 둥근 모서리 */
  overflow: hidden;              /* 차트가 모서리를 삐져나오지 않게 */
  height: 400px;
  display: flex;
  flex-direction: column;
  background: #ffffff;
}
.chart-wrapper {
  height: 260px;
}
.range-buttons {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 0.75rem;
}
.loading {
  font-size: 14px;
  color: #6b7280;
}
.error {
  font-size: 14px;
  color: #ef4444;
}
</style>
