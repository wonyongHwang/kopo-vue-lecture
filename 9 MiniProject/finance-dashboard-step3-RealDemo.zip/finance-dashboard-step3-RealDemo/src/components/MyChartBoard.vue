<!-- src/components/MyChartBoard.vue -->
<template>

  <div class="dashboard-card board">
    <v-row>
      <v-col cols="12" md="6">
        <CryptoLineChart asset="btc" title="Bitcoin (BTC)" />
      </v-col>
      <v-col cols="12" md="6">
        <CryptoLineChart asset="eth" title="Ethereum (ETH)" />
      </v-col>
    </v-row>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import CryptoLineChart from './CryptoLineChart.vue'
import { useChartPrefStore } from '../stores/chartPrefStore'

const chartPrefStore = useChartPrefStore()

onMounted(() => {
  // 로그인 후 Dashboard로 들어올 때 차트 설정 미리 불러오기
  chartPrefStore.loadPrefs()
})
</script>

<style scoped>
.board {
  margin-top: 16px;
}
</style>
