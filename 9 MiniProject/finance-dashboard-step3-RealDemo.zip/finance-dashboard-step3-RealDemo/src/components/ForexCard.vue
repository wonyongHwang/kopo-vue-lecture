<template>
    <v-card class="finance-card">

      <v-card-title>
        환율 정보 (USD 기준)
      </v-card-title>
  
      <v-card-subtitle v-if="lastDate">
        기준일: {{ lastDate }}
      </v-card-subtitle>
  
      <v-card-text>
        <div v-if="loading" class="text-center">
          <v-progress-circular indeterminate />
          <div class="mt-2">환율 불러오는 중...</div>
        </div>
  
        <div v-else-if="error" class="error">
          {{ error }}
        </div>
  
        <div v-else>
          <v-list density="compact">
            <v-list-item
              v-for="(value, currency) in rates"
              :key="currency"
            >
              <v-list-item-title>
                1 USD = <strong>{{ value }}</strong> {{ currency }}
              </v-list-item-title>
            </v-list-item>
          </v-list>
        </div>
      </v-card-text>
    </v-card>
  </template>
  
  <script setup>
  import { ref, onMounted } from 'vue'
  import { fetchUsdToKrwAndOthers } from '../services/forexApi'
  
  const rates = ref({})
  const loading = ref(false)
  const error = ref('')
  const lastDate = ref('')
  
  onMounted(async () => {
    loading.value = true
    error.value = ''
  
    try {
      const data = await fetchUsdToKrwAndOthers()
      // data: { amount, base, date, rates: { KRW: ..., EUR: ..., JPY: ... } }
      rates.value = data.rates
      lastDate.value = data.date
    } catch (err) {
      console.error(err)
      error.value = '환율 정보를 가져오는데 실패했습니다.'
    } finally {
      loading.value = false
    }
  })
  </script>
  
  <style scoped>
  .error {
    color: red;
  }
  .text-center {
    text-align: center;
  }
  .mt-2 {
    margin-top: 0.5rem;
  }
  </style>
  