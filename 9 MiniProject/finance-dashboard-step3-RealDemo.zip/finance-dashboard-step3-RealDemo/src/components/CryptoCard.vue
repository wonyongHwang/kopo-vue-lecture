<template>
    <v-card class="finance-card">

      <v-card-title>
        암호화폐 시세
      </v-card-title>
  
      <v-card-subtitle>
        Bitcoin / Ethereum (USD, KRW)
      </v-card-subtitle>
  
      <v-card-text>
        <div v-if="loading" class="text-center">
          <v-progress-circular indeterminate />
          <div class="mt-2">암호화폐 가격 불러오는 중...</div>
        </div>
  
        <div v-else-if="error" class="error">
          {{ error }}
        </div>
  
        <div v-else>
          <v-list density="compact">
            <v-list-item>
              <v-list-item-title>
                <strong>Bitcoin (BTC)</strong>
              </v-list-item-title>
              <v-list-item-subtitle>
                {{ prices.bitcoin?.usd }} USD /
                {{ prices.bitcoin?.krw }} KRW
              </v-list-item-subtitle>
            </v-list-item>
  
            <v-list-item>
              <v-list-item-title>
                <strong>Ethereum (ETH)</strong>
              </v-list-item-title>
              <v-list-item-subtitle>
                {{ prices.ethereum?.usd }} USD /
                {{ prices.ethereum?.krw }} KRW
              </v-list-item-subtitle>
            </v-list-item>
          </v-list>
        </div>
      </v-card-text>
    </v-card>
  </template>
  
  <script setup>
  import { ref, onMounted } from 'vue'
  import { fetchSimpleCryptoPrices } from '../services/cryptoApi'
  
  const prices = ref({})
  const loading = ref(false)
  const error = ref('')
  
  onMounted(async () => {
    loading.value = true
    error.value = ''
  
    try {
      const data = await fetchSimpleCryptoPrices()
      // data: { bitcoin: { usd, krw }, ethereum: { usd, krw } }
      prices.value = data
    } catch (err) {
      console.error(err)
      error.value = '암호화폐 정보를 가져오는데 실패했습니다.'
    } finally {
      loading.value = false
    }
  })
  </script>
  
  <style scoped>
  .error {
    color: red;
  }
  .text-center {
    text-align: center;
  }
  .mt-2 {
    margin-top: 0.5rem;
  }
  </style>
  