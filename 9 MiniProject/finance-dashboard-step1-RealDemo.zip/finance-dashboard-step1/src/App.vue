<!-- src/App.vue -->
<template>
  <div id="app">
    <!-- 공통 헤더 -->
    <header class="app-header">
      <h1 class="logo">Finance Dashboard</h1>
    </header>

    <!-- 페이지가 바뀌는 공간 -->
    <main class="app-content">
      <router-view />
    </main>
  </div>
</template>

<script setup>
/* 1단계에서는 특별한 로직 없음 */
/* 2단계에서 레이아웃 확장, 3단계에서 로그인 상태 반영 예정 */
</script>

<style>
/* 전체 기본 레이아웃 */
#app {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica,
    Arial, sans-serif;
  color: #333;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* 헤더 (단순 버전) */
.app-header {
  background: #1976d2; /* 블루 계열 */
  padding: 1rem;
  color: white;
  text-align: center;
}

.logo {
  font-size: 1.4rem;
  margin: 0;
}

/* 콘텐츠 영역 */
.app-content {
  flex: 1;
  padding: 1.5rem;
  max-width: 960px;
  margin: 0 auto;
}
</style>
