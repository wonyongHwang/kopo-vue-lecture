<template>
    <div class="dashboard">
      <h1>금융 대시보드 (1단계 버전)</h1>
  
      <section>
        <h2>환율 (USD 기준)</h2>
        <p v-if="forexLoading">환율 불러오는 중...</p>
        <p v-else-if="forexError" class="error">{{ forexError }}</p>
        <ul v-else>
          <li v-for="(value, currency) in forexRates" :key="currency">
            1 USD = {{ value }} {{ currency }}
          </li>
        </ul>
      </section>
  
      <section>
        <h2>암호화폐 시세</h2>
        <p v-if="cryptoLoading">암호화폐 가격 불러오는 중...</p>
        <p v-else-if="cryptoError" class="error">{{ cryptoError }}</p>
        <ul v-else>
          <li>
            Bitcoin (BTC) : {{ cryptoPrices.bitcoin?.usd }} USD /
            {{ cryptoPrices.bitcoin?.krw }} KRW
          </li>
          <li>
            Ethereum (ETH) : {{ cryptoPrices.ethereum?.usd }} USD /
            {{ cryptoPrices.ethereum?.krw }} KRW
          </li>
        </ul>
      </section>
    </div>
  </template>
  
  <script setup>
  import { ref, onMounted } from 'vue'
  import { fetchUsdToKrwAndOthers } from '../services/forexApi'
  import { fetchSimpleCryptoPrices } from '../services/cryptoApi'
  
  const forexRates = ref({})
  const forexLoading = ref(false)
  const forexError = ref('')
  
  const cryptoPrices = ref({})
  const cryptoLoading = ref(false)
  const cryptoError = ref('')
  
  onMounted(async () => {
    // 환율
    forexLoading.value = true
    try {
      const data = await fetchUsdToKrwAndOthers()
      console.log("forex data ",data)
      forexRates.value = data.rates
    } catch (err) {
      forexError.value = '환율 정보를 가져오는데 실패했습니다.'
      console.error(err)
    } finally {
      forexLoading.value = false
    }
  
    // 암호화폐
    cryptoLoading.value = true
    try {
      const data = await fetchSimpleCryptoPrices()
      console.log("crypto data ",data)

      cryptoPrices.value = data
    } catch (err) {
      cryptoError.value = '암호화폐 정보를 가져오는데 실패했습니다.'
      console.error(err)
    } finally {
      cryptoLoading.value = false
    }
  })
  </script>
  
  <style scoped>
  .dashboard {
    max-width: 960px;
    margin: 0 auto;
    padding: 1rem;
  }
  .error {
    color: red;
  }
  </style>
  