<template>
    <div class="auth-page">
      <h1>로그인</h1>
      <form @submit.prevent="handleLogin">
        <label>
          이메일
          <input v-model="email" type="email" required />
        </label>
        <label>
          비밀번호
          <input v-model="password" type="password" required />
        </label>
  
        <button type="submit">로그인 (1단계: 더미)</button>
      </form>
  
      <p>
        아직 계정이 없나요?
        <router-link to="/register">회원가입 하러 가기</router-link>
      </p>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue'
  import { useRouter } from 'vue-router'
  
  const email = ref('')
  const password = ref('')
  
  const router = useRouter()
  
  const handleLogin = () => {
    // 1단계: 실제 인증 없음, 바로 대시보드로
    router.push('/dashboard')
  }
  </script>
  
  <style scoped>
  .auth-page {
    max-width: 480px;
    margin: 0 auto;
  }
  </style>
  