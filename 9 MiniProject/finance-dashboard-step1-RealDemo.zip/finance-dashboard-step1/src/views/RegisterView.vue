<!-- src/views/RegisterView.vue -->
<template>
    <div class="auth-page">
      <h1>회원가입</h1>
  
      <form @submit.prevent="handleRegister">
        <label>
          이메일
          <input v-model="email" type="email" required />
        </label>
  
        <label>
          비밀번호
          <input v-model="password" type="password" required />
        </label>
  
        <label>
          비밀번호 확인
          <input v-model="passwordConfirm" type="password" required />
        </label>
  
        <button type="submit">
          회원가입 (1단계: 더미)
        </button>
      </form>
  
      <p class="hint">
        이미 계정이 있나요?
        <router-link to="/login">로그인 하러 가기</router-link>
      </p>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue'
  import { useRouter } from 'vue-router'
  
  const email = ref('')
  const password = ref('')
  const passwordConfirm = ref('')
  
  const router = useRouter()
  
  const handleRegister = () => {
    if (password.value !== passwordConfirm.value) {
      alert('비밀번호가 일치하지 않습니다.')
      return
    }
  
    // 1단계: 실제 Firebase 등록 없이, 그냥 안내 후 로그인 페이지로 이동
    alert('1단계 데모: 회원가입이 완료되었다고 가정하고 로그인 화면으로 이동합니다.')
    router.push('/login')
  }
  </script>
  
  <style scoped>
  .auth-page {
    max-width: 480px;
    margin: 2rem auto;
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }
  
  form {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
  }
  
  label {
    display: flex;
    flex-direction: column;
    font-size: 0.9rem;
    gap: 0.25rem;
  }
  
  input {
    padding: 0.5rem;
    font-size: 1rem;
  }
  
  button {
    margin-top: 0.5rem;
    padding: 0.6rem;
    font-size: 1rem;
    cursor: pointer;
  }
  
  .hint {
    margin-top: 1rem;
    font-size: 0.9rem;
  }
  </style>
  