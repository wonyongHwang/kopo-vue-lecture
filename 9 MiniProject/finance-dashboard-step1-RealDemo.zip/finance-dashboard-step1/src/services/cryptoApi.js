import axios from 'axios'

const BASE_URL = 'https://api.coingecko.com/api/v3'

export async function fetchSimpleCryptoPrices() {
  const response = await axios.get(
    `${BASE_URL}/simple/price`,
    {
      params: {
        ids: 'bitcoin,ethereum',
        vs_currencies: 'usd,krw'
      }
    }
  )
  return response.data  // { bitcoin: { usd: ..., krw: ... }, ... }
}
