<template>
  <v-app>
    <v-app-bar app flat color="#0f172a" density="comfortable">
      <v-app-bar-title class="text-white">
        Finance Dashboard
      </v-app-bar-title>

      <v-spacer />

      <div v-if="isLoggedIn" class="d-flex align-center">
        <span class="user-email">
          {{ userEmail }}
        </span>
        <v-btn
          size="small"
          variant="outlined"
          color="white"
          class="ml-3"
          @click="handleLogout"
        >
          로그아웃
        </v-btn>
      </div>

      <div v-else class="d-flex align-center">
        <v-btn
          size="small"
          variant="text"
          color="white"
          @click="goLogin"
        >
          로그인
        </v-btn>
        <v-btn
          size="small"
          variant="outlined"
          color="white"
          class="ml-2"
          @click="goRegister"
        >
          회원가입
        </v-btn>
      </div>
    </v-app-bar>

    <v-main class="bg-blue-grey-lighten-5">
      <v-container fluid class="py-6">
        <router-view />
      </v-container>
    </v-main>

  </v-app>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()


const isLoggedIn = ref(false)
const userEmail = ref('')

const handleLogout = async () => {
 
}

const goLogin = () => {
  router.push('/login')
}

const goRegister = () => {
  router.push('/register')
}
</script>

<style scoped>
.user-email {
  color: #e5e7eb;
  font-size: 0.9rem;
}

.ml-2 {
  margin-left: 0.5rem;
}

.ml-3 {
  margin-left: 0.75rem;
}

/* 공통 카드 스타일 */
.dashboard-card {
  background: #ffffff;
  border-radius: 16px;     /* 🔥 라운드 처리 */
  padding: 24px;
  box-shadow: 0 6px 24px rgba(0, 0, 0, 0.06);
}

</style>
