<!-- src/views/LoginView.vue -->
<template>
  <div class="login-page">
    <div class="login-card">
      <h1 class="login-title">로그인</h1>

      <form @submit.prevent="handleLogin">
        <div class="form-row">
          <label for="email">이메일</label>
          <input
            id="email"
            v-model="email"
            type="email"
            placeholder="example@email.com"
          />
        </div>

        <div class="form-row">
          <label for="password">비밀번호</label>
          <input
            id="password"
            v-model="password"
            type="password"
            placeholder="8자 이상 입력"
          />
        </div>

        <button type="submit" class="login-btn">
          로그인
        </button>
      </form>

      <p class="signup-text">
        아직 계정이 없나요?
        <RouterLink to="/register" class="signup-link">
          회원가입 하러 가기
        </RouterLink>
      </p>
    </div>
  </div>
</template>

<script setup>
  import { ref } from 'vue'
  import { useRouter } from 'vue-router'
  
  const email = ref('')
  const password = ref('')
  
  const router = useRouter()
  

  
  const handleLogin = async () => {
    try {
    
      router.push('/dashboard')
    } catch (err) {
     
      console.error(err)
    }
  }
</script>

<style scoped>
/* 화면 전체 가운데 정렬 + 배경색 */
.login-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f3f4f6; /* 연한 회색 배경 */
}

/* 카드 박스 */
.login-card {
  width: 100%;
  max-width: 420px;         /* 너무 넓지 않게 */
  padding: 40px 32px;
  border-radius: 16px;
  background: #ffffff;
  box-shadow: 0 10px 30px rgba(15, 23, 42, 0.12); /* 살짝 그림자 */
}

/* 제목 */
.login-title {
  margin-bottom: 24px;
  font-size: 28px;
  font-weight: 700;
}

/* 폼 행 */
.form-row {
  display: flex;
  flex-direction: column;
  margin-bottom: 16px;
}

label {
  font-size: 14px;
  margin-bottom: 6px;
  color: #4b5563;
}

/* 인풋 스타일 – 테두리, 패딩 키우기 */
input {
  padding: 10px 12px;
  border-radius: 8px;
  border: 1px solid #d1d5db;
  font-size: 15px;
  outline: none;
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}

input:focus {
  border-color: #6366f1;
  box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
}

/* 로그인 버튼 크게 + 전체 너비 */
.login-btn {
  width: 100%;
  margin-top: 8px;
  padding: 12px 0;
  font-size: 16px;
  font-weight: 600;
  border-radius: 999px;
  border: none;
  cursor: pointer;
  background: #6366f1;
  color: white;
  transition: background 0.15s ease, transform 0.05s ease;
}

.login-btn:hover {
  background: #4f46e5;
}

.login-btn:active {
  transform: translateY(1px);
}

/* 회원가입 영역 */
.signup-text {
  margin-top: 16px;
  font-size: 14px;
  text-align: center;
  color: #6b7280;
}

.signup-link {
  margin-left: 4px;
  color: #4f46e5;
  text-decoration: underline;
  font-weight: 500;
}
</style>
