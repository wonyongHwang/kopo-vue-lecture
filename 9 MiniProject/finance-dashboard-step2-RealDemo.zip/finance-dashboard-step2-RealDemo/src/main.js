import { createApp } from 'vue'
import App from './App.vue'
import router from './router'

import 'vuetify/styles' // step 2
import { createVuetify } from 'vuetify' // step 2
import * as components from 'vuetify/components' // step 2
import * as directives from 'vuetify/directives' // step 2
// components, directives: Vuetify 컴포넌트를 전역 등록
// theme: 라이트/다크 테마 정의
const vuetify = createVuetify({
    components,
    directives,
    theme: {
      defaultTheme: 'light',
      themes: {
        light: { dark: false },
        dark: { dark: true }
      }
    }
  })
const app = createApp(App)

app.use(router)
app.use(vuetify) // step 2

app.mount('#app')
